package bancario;

public abstract class MedioPago {

    protected String titular;
    protected double saldo;

    public MedioPago(String titular, double saldo) {
        this.titular = titular;
        this.saldo = saldo;
    }

    public void consultarSaldo() {
        System.out.println("Saldo de " + titular + ": " + saldo);
    }

    public abstract void pagar(double monto);

    public String getTitular() {
        return titular;
    }

    public double getSaldo() {
        return saldo;
    }
}
