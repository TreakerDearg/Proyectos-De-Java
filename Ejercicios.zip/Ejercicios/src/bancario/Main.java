package bancario;

public class Main {

    public static void main(String[] args) {
        MedioPago tarjeta = new TarjetaCredito("Ana", 0, 50000);
        MedioPago sube = new TarjetaSUBE("Luis", 500);
        MedioPago billetera = new BilleteraVirtual("Marta", 2000);

        tarjeta.pagar(1500);
        sube.pagar(200);
        billetera.pagar(500);

        tarjeta.consultarSaldo();
        sube.consultarSaldo();
        billetera.consultarSaldo();

        ((Recargable) sube).recargar(300);
        ((Recargable) billetera).recargar(1000);
    }
}
