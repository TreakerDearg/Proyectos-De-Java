package bancario;

public class BilleteraVirtual extends MedioPago implements Recargable {

    public BilleteraVirtual(String titular, double saldo) {
        super(titular, saldo);
    }

    @Override
    public void pagar(double monto) {
        if (monto > saldo) {
            System.out.println("Saldo insuficiente en la billetera virtual.");
            return;
        }
        saldo -= monto;
        System.out.println("Pago de " + monto + " realizado con billetera virtual.");
    }

    @Override
    public void recargar(double monto) {
        saldo += monto;
        System.out.println("Se recargaron " + monto + " a la billetera virtual.");
    }
}
