package bancario;

public interface Recargable {
    void recargar(double monto);
}
