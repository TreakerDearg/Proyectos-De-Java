package bancario;

public class TarjetaCredito extends MedioPago {

    private double limite;

    public TarjetaCredito(String titular, double saldo, double limite) {
        super(titular, saldo);
        this.limite = limite;
    }

    @Override
    public void pagar(double monto) {
        if (saldo + monto > limite) {
            System.out.println("Pago rechazado: supera el límite de la tarjeta.");
            return;
        }
        saldo += monto;
        System.out.println("Pago de " + monto + " realizado con tarjeta de crédito.");
    }
}
