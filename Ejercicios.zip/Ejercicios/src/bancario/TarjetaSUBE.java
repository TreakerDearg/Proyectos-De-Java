package bancario;

public class TarjetaSUBE extends MedioPago implements Recargable {

    public TarjetaSUBE(String titular, double saldo) {
        super(titular, saldo);
    }

    @Override
    public void pagar(double monto) {
        if (monto > saldo) {
            System.out.println("Saldo insuficiente en la tarjeta SUBE.");
            return;
        }
        saldo -= monto;
        System.out.println("Pago de " + monto + " realizado con tarjeta SUBE.");
    }

    @Override
    public void recargar(double monto) {
        saldo += monto;
        System.out.println("Se recargaron " + monto + " a la tarjeta SUBE.");
    }
}
