package notificaciones;

import java.util.Date;

public interface Programable {
    void programar(Date fecha);
}
