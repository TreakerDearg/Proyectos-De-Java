package notificaciones;

import java.util.Date;

public class Main {

    public static void main(String[] args) {
        Notificacion email = new Email("juan@correo.com", "Bienvenido");
        Notificacion sms = new SMS("+54911111111", "Tu código es 1234");
        Notificacion whatsapp = new WhatsApp("+54922222222", "Tu pedido salió");

        email.enviar();
        sms.enviar();
        whatsapp.enviar();

        ((Programable) email).programar(new Date());
        ((Programable) whatsapp).programar(new Date());
    }
}
