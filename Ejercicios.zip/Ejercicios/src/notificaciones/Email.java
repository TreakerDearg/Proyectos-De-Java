package notificaciones;

import java.util.Date;

public class Email extends Notificacion implements Programable {

    public Email(String destinatario, String mensaje) {
        super(destinatario, mensaje);
    }

    @Override
    public void enviar() {
        System.out.println("Enviando EMAIL a " + destinatario + ": " + mensaje);
        registrarEnvio();
    }

    @Override
    public void programar(Date fecha) {
        System.out.println("Email programado para " + fecha);
    }
}
