package notificaciones;

import java.util.Date;

public class WhatsApp extends Notificacion implements Programable {

    public WhatsApp(String destinatario, String mensaje) {
        super(destinatario, mensaje);
    }

    @Override
    public void enviar() {
        System.out.println("Enviando WHATSAPP a " + destinatario + ": " + mensaje);
        registrarEnvio();
    }

    @Override
    public void programar(Date fecha) {
        System.out.println("WhatsApp programado para " + fecha);
    }
}
