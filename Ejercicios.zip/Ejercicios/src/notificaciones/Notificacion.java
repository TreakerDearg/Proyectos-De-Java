package notificaciones;

public abstract class Notificacion {

    protected String destinatario;
    protected String mensaje;

    public Notificacion(String destinatario, String mensaje) {
        this.destinatario = destinatario;
        this.mensaje = mensaje;
    }

    public void registrarEnvio() {
        System.out.println("Registro: notificación enviada a " + destinatario);
    }

    public abstract void enviar();

    public String getDestinatario() {
        return destinatario;
    }

    public String getMensaje() {
        return mensaje;
    }
}
