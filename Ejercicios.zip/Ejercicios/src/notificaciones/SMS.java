package notificaciones;

public class SMS extends Notificacion {

    public SMS(String destinatario, String mensaje) {
        super(destinatario, mensaje);
    }

    @Override
    public void enviar() {
        System.out.println("Enviando SMS a " + destinatario + ": " + mensaje);
        registrarEnvio();
    }
}
