package main;

import controlador.CalificacionesController;
import modelo.CalificacionesModelo;
import vista.SistemaCalificacionesFrame;

/**
 *
 * @author (tu nombre aquí)
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                CalificacionesModelo unModelo = new CalificacionesModelo();
                SistemaCalificacionesFrame unaVista = new SistemaCalificacionesFrame();
                CalificacionesController unController = new CalificacionesController(unModelo, unaVista);

                unaVista.setVisible(true);
            }
        });
    }
}
