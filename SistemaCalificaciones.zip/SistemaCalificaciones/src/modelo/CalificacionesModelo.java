package modelo;

/**
 * Modelo del Sistema de Calificaciones.
 * Solo contiene los datos y la lógica real (validar, calcular,
 * ordenar). No conoce nada de Swing ni de la vista, igual que
 * "calculadora" en el proyecto de ejemplo.
 */
public class CalificacionesModelo {

    private int[] calificaciones;

    /** Indica si ya hay calificaciones válidas guardadas. */
    public boolean hayDatos() {
        return calificaciones != null;
    }

    /** Descarta las calificaciones guardadas. */
    public void reiniciar() {
        calificaciones = null;
    }

    /**
     * Valida el texto recibido (una nota por estudiante) y, si todo
     * es correcto, lo guarda como el nuevo conjunto de calificaciones.
     *
     * @return null si todo es válido; en caso contrario, el mensaje de error
     */
    public String validarYGuardar(String[] valoresTexto) {
        int[] nuevasCalificaciones = new int[valoresTexto.length];

        for (int i = 0; i < valoresTexto.length; i++) {
            try {
                int nota = Integer.parseInt(valoresTexto[i].trim());
                if (nota < 0 || nota > 10) {
                    return "La calificación del estudiante " + (i + 1) + " debe estar entre 0 y 10.";
                }
                nuevasCalificaciones[i] = nota;
            } catch (NumberFormatException error) {
                return "La calificación del estudiante " + (i + 1) + " no es un número válido.";
            }
        }

        calificaciones = nuevasCalificaciones;
        return null;
    }

    /** Devuelve una copia de las calificaciones (para no exponer el arreglo interno). */
    public int[] obtenerCalificaciones() {
        return calificaciones.clone();
    }

    /** Calcula el promedio del grupo. */
    public double calcularPromedio() {
        int suma = 0;
        for (int nota : calificaciones) {
            suma += nota;
        }
        return (double) suma / calificaciones.length;
    }

    /** Devuelve la calificación más alta del grupo. */
    public int obtenerMaxima() {
        int maxima = calificaciones[0];
        for (int nota : calificaciones) {
            if (nota > maxima) maxima = nota;
        }
        return maxima;
    }

    /** Devuelve la calificación más baja del grupo. */
    public int obtenerMinima() {
        int minima = calificaciones[0];
        for (int nota : calificaciones) {
            if (nota < minima) minima = nota;
        }
        return minima;
    }

    /** Cuenta cuántos estudiantes tienen calificación aprobatoria (>= 6). */
    public int contarAprobados() {
        int aprobados = 0;
        for (int nota : calificaciones) {
            if (nota >= 6) aprobados++;
        }
        return aprobados;
    }

    /** Devuelve la cantidad total de estudiantes con datos guardados. */
    public int obtenerCantidadEstudiantes() {
        return calificaciones.length;
    }

    /** Devuelve una copia de las calificaciones ordenadas de menor a mayor. */
    public int[] obtenerOrdenAscendente() {
        int[] ordenadas = calificaciones.clone();
        ordenarBurbuja(ordenadas);
        return ordenadas;
    }

    /** Ordena un arreglo de enteros de menor a mayor usando el método burbuja. */
    private void ordenarBurbuja(int[] arreglo) {
        for (int i = 0; i < arreglo.length - 1; i++) {
            for (int j = 0; j < arreglo.length - 1 - i; j++) {
                if (arreglo[j] > arreglo[j + 1]) {
                    int temporal = arreglo[j];
                    arreglo[j] = arreglo[j + 1];
                    arreglo[j + 1] = temporal;
                }
            }
        }
    }
}
