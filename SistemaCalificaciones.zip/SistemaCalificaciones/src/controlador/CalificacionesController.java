package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.CalificacionesModelo;
import vista.SistemaCalificacionesFrame;

/**
 *
 * @author (tu nombre aquí)
 */
public class CalificacionesController {

    private CalificacionesModelo unModelo;
    private SistemaCalificacionesFrame unaVista;

    public CalificacionesController(CalificacionesModelo unModelo, SistemaCalificacionesFrame unaVista) {
        this.unModelo = unModelo;
        this.unaVista = unaVista;

        unaVista.getBtnGenerar().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                generarTabla();
            }
        });

        unaVista.getBtnIngresar().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ingresarCalificaciones();
            }
        });

        unaVista.getBtnMostrar().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mostrarCalificaciones();
            }
        });

        unaVista.getBtnPromedio().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mostrarPromedio();
            }
        });

        unaVista.getBtnMaxMin().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mostrarMaximaMinima();
            }
        });

        unaVista.getBtnAprobados().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mostrarAprobados();
            }
        });

        unaVista.getBtnOrdenar().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mostrarOrdenAscendente();
            }
        });
    }

    // ---------------------------------------------------------------
    // Un método por botón (llamado desde el listener correspondiente)
    // ---------------------------------------------------------------

    private void generarTabla() {
        int cantidad;
        try {
            cantidad = Integer.parseInt(unaVista.getTxtCantidad().getText().trim());
            if (cantidad <= 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException error) {
            JOptionPane.showMessageDialog(unaVista,
                    "Ingrese un número entero mayor que 0.",
                    "Cantidad inválida", JOptionPane.ERROR_MESSAGE);
            return;
        }

        DefaultTableModel modeloTabla = new DefaultTableModel(
                new String[]{"Estudiante", "Calificación"}, 0) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return columna == 1; // Solo la columna "Calificación" es editable
            }
        };
        for (int i = 1; i <= cantidad; i++) {
            modeloTabla.addRow(new Object[]{"Estudiante " + i, ""});
        }
        unaVista.getTblCalificaciones().setModel(modeloTabla);

        unModelo.reiniciar(); // Los datos anteriores ya no son válidos
        unaVista.getTxtResultados().setText("Tabla generada. Complete las calificaciones (0-10) "
                + "y presione \"Ingresar calificaciones\".");
    }

    private void ingresarCalificaciones() {
        int filas = unaVista.getTblCalificaciones().getRowCount();
        if (filas == 0) {
            JOptionPane.showMessageDialog(unaVista,
                    "Primero genere la tabla indicando la cantidad de estudiantes.",
                    "Faltan datos", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String[] valores = new String[filas];
        for (int i = 0; i < filas; i++) {
            Object valor = unaVista.getTblCalificaciones().getValueAt(i, 1);
            valores[i] = (valor == null) ? "" : valor.toString();
        }

        String error = unModelo.validarYGuardar(valores);
        if (error != null) {
            JOptionPane.showMessageDialog(unaVista, error,
                    "Calificación inválida", JOptionPane.ERROR_MESSAGE);
            return;
        }

        unaVista.getTxtResultados().setText("Calificaciones ingresadas correctamente.");
    }

    private void mostrarCalificaciones() {
        if (!hayDatos()) return;

        int[] calificaciones = unModelo.obtenerCalificaciones();
        StringBuilder texto = new StringBuilder("--- Calificaciones ---\n");
        for (int i = 0; i < calificaciones.length; i++) {
            texto.append("Estudiante ").append(i + 1)
                    .append(": ").append(calificaciones[i]).append("\n");
        }
        unaVista.getTxtResultados().setText(texto.toString());
    }

    private void mostrarPromedio() {
        if (!hayDatos()) return;
        double promedio = unModelo.calcularPromedio();
        unaVista.getTxtResultados().setText(String.format("El promedio del grupo es: %.2f", promedio));
    }

    private void mostrarMaximaMinima() {
        if (!hayDatos()) return;
        int maxima = unModelo.obtenerMaxima();
        int minima = unModelo.obtenerMinima();
        unaVista.getTxtResultados().setText("Calificación más alta: " + maxima
                + "\nCalificación más baja: " + minima);
    }

    private void mostrarAprobados() {
        if (!hayDatos()) return;
        int aprobados = unModelo.contarAprobados();
        int total = unModelo.obtenerCantidadEstudiantes();
        unaVista.getTxtResultados().setText("Estudiantes aprobados: " + aprobados + " de " + total);
    }

    private void mostrarOrdenAscendente() {
        if (!hayDatos()) return;
        int[] ordenadas = unModelo.obtenerOrdenAscendente();
        StringBuilder texto = new StringBuilder("--- Calificaciones en orden ascendente ---\n");
        for (int nota : ordenadas) {
            texto.append(nota).append(" ");
        }
        unaVista.getTxtResultados().setText(texto.toString());
    }

    /** Verifica que ya se hayan ingresado y validado las calificaciones. */
    private boolean hayDatos() {
        if (!unModelo.hayDatos()) {
            JOptionPane.showMessageDialog(unaVista,
                    "Primero debe ingresar las calificaciones.",
                    "Faltan datos", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }
}
