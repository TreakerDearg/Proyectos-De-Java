package modelo;

/**
 * Modelo de la Calculadora.
 * Solo contiene los datos (los dos valores) y las operaciones
 * aritméticas. No conoce nada de Swing ni de la vista.
 */
public class CalculadoraModelo {

    private double valor1;
    private double valor2;

    public void setValor1(double valor1) {
        this.valor1 = valor1;
    }

    public double getValor1() {
        return valor1;
    }

    public void setValor2(double valor2) {
        this.valor2 = valor2;
    }

    public double getValor2() {
        return valor2;
    }

    public double sumar() {
        return valor1 + valor2;
    }

    public double restar() {
        return valor1 - valor2;
    }

    public double multiplicar() {
        return valor1 * valor2;
    }

    /**
     * Divide valor1 entre valor2.
     * @throws ArithmeticException si valor2 es 0
     */
    public double dividir() {
        if (valor2 == 0) {
            throw new ArithmeticException("No se puede dividir entre cero.");
        }
        return valor1 / valor2;
    }
}
