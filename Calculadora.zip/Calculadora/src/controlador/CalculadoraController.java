package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import modelo.CalculadoraModelo;
import vista.CalculadoraFrame;

/**
 *
 * @author (tu nombre aquí)
 */
public class CalculadoraController {

    private CalculadoraModelo unModelo;
    private CalculadoraFrame unaVista;

    public CalculadoraController(CalculadoraModelo unModelo, CalculadoraFrame unaVista) {
        this.unModelo = unModelo;
        this.unaVista = unaVista;

        unaVista.getBtnSumar().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (leerValores()) {
                    mostrarResultado(unModelo.sumar());
                }
            }
        });

        unaVista.getBtnRestar().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (leerValores()) {
                    mostrarResultado(unModelo.restar());
                }
            }
        });

        unaVista.getBtnMultiplicar().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (leerValores()) {
                    mostrarResultado(unModelo.multiplicar());
                }
            }
        });

        unaVista.getBtnDividir().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (leerValores()) {
                    try {
                        mostrarResultado(unModelo.dividir());
                    } catch (ArithmeticException error) {
                        JOptionPane.showMessageDialog(unaVista,
                                "No se puede dividir entre cero.",
                                "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
    }

    /** Lee y valida los dos valores escritos en la vista, y los guarda en el modelo. */
    private boolean leerValores() {
        try {
            double valor1 = Double.parseDouble(unaVista.getTxtValor1().getText().trim());
            double valor2 = Double.parseDouble(unaVista.getTxtValor2().getText().trim());
            unModelo.setValor1(valor1);
            unModelo.setValor2(valor2);
            return true;
        } catch (NumberFormatException error) {
            JOptionPane.showMessageDialog(unaVista,
                    "Ingrese dos números válidos.",
                    "Valor inválido", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    /** Muestra el resultado en el campo correspondiente de la vista. */
    private void mostrarResultado(double resultado) {
        unaVista.getTxtResultado().setText(String.valueOf(resultado));
    }
}
