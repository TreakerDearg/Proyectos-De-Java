package main;

import controlador.CalculadoraController;
import modelo.CalculadoraModelo;
import vista.CalculadoraFrame;

/**
 *
 * @author (tu nombre aquí)
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                CalculadoraModelo unModelo = new CalculadoraModelo();
                CalculadoraFrame unaVista = new CalculadoraFrame();
                CalculadoraController unController = new CalculadoraController(unModelo, unaVista);

                unaVista.setVisible(true);
            }
        });
    }
}
