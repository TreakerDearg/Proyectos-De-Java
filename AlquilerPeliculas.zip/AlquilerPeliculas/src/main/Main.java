package main;

import controlador.AlquilerController;
import modelo.AlquilerModelo;
import vista.AlquilerFrame;

/**
 *
 * @author (tu nombre aquí)
 */
public class Main {

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                AlquilerModelo unModelo = new AlquilerModelo();
                AlquilerFrame unaVista = new AlquilerFrame();
                AlquilerController unController = new AlquilerController(unModelo, unaVista);

                unaVista.setVisible(true);
            }
        });
    }
}
