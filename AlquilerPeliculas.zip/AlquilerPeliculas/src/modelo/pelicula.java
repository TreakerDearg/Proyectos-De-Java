package modelo;

public class pelicula {

    private int codigo;
    private String nombre;
    private String genero;
    private double precio;

    public pelicula(int codigo, String nombre, String genero, double precio) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.genero = genero;
        this.precio = precio;
    }

    public String getnombre() {
        return nombre;
    }
}
