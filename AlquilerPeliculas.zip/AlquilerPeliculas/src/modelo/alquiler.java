package modelo;

import java.util.Date;

public class alquiler {

    private int codigo;
    private cliente unCliente;
    private pelicula unPelicula1;
    private pelicula unPelicula2;
    private Date fecha;

    public alquiler(int codigo, cliente unCliente, pelicula unPelicula1, pelicula unPelicula2, Date fecha) {
        this.codigo = codigo;
        this.unCliente = unCliente;
        this.unPelicula1 = unPelicula1;
        this.unPelicula2 = unPelicula2;
        this.fecha = fecha;
    }

    public pelicula getunPelicula1() {
        return unPelicula1;
    }

    public pelicula getunPelicula2() {
        return unPelicula2;
    }

    public cliente getunCliente() {
        return unCliente;
    }
}
