package modelo;

import java.util.Date;

public class AlquilerModelo {

    private int contadorAlquiler = 0;
    private int contadorCliente = 0;
    private int contadorPelicula = 0;

    public alquiler registrarAlquiler(String nombreCliente, long telefonoCliente,
                                       String nombrePelicula1, String generoPelicula1, double precioPelicula1,
                                       String nombrePelicula2, String generoPelicula2, double precioPelicula2) {

        contadorCliente++;
        cliente unCliente = new cliente(contadorCliente, nombreCliente, telefonoCliente);

        contadorPelicula++;
        pelicula peli1 = new pelicula(contadorPelicula, nombrePelicula1, generoPelicula1, precioPelicula1);

        contadorPelicula++;
        pelicula peli2 = new pelicula(contadorPelicula, nombrePelicula2, generoPelicula2, precioPelicula2);

        contadorAlquiler++;
        return new alquiler(contadorAlquiler, unCliente, peli1, peli2, new Date());
    }
}
