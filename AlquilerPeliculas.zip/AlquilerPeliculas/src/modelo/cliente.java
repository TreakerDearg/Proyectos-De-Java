package modelo;

public class cliente {

    private int codigo;
    private String nombre;
    private long telefono;

    public cliente(int codigo, String nombre, long telefono) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.telefono = telefono;
    }

    public String getnombre() {
        return nombre;
    }
}
