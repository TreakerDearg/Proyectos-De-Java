package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import modelo.AlquilerModelo;
import modelo.alquiler;
import vista.AlquilerFrame;

/**
 *
 * @author (tu nombre aquí)
 */
public class AlquilerController {

    private AlquilerModelo unModelo;
    private AlquilerFrame unaVista;

    public AlquilerController(AlquilerModelo unModelo, AlquilerFrame unaVista) {
        this.unModelo = unModelo;
        this.unaVista = unaVista;

        unaVista.getBtnRegistrar().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                registrarAlquiler();
            }
        });
    }

    private void registrarAlquiler() {
        String nombreCliente = unaVista.getTxtNombreCliente().getText().trim();
        String nombrePelicula1 = unaVista.getTxtNombrePelicula1().getText().trim();
        String generoPelicula1 = unaVista.getTxtGeneroPelicula1().getText().trim();
        String nombrePelicula2 = unaVista.getTxtNombrePelicula2().getText().trim();
        String generoPelicula2 = unaVista.getTxtGeneroPelicula2().getText().trim();

        if (nombreCliente.isEmpty() || nombrePelicula1.isEmpty() || nombrePelicula2.isEmpty()) {
            JOptionPane.showMessageDialog(unaVista,
                    "Complete al menos el nombre del cliente y de ambas películas.",
                    "Datos incompletos", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            long telefonoCliente = Long.parseLong(unaVista.getTxtTelefonoCliente().getText().trim());
            double precioPelicula1 = Double.parseDouble(unaVista.getTxtPrecioPelicula1().getText().trim());
            double precioPelicula2 = Double.parseDouble(unaVista.getTxtPrecioPelicula2().getText().trim());

            alquiler unAlquiler = unModelo.registrarAlquiler(
                    nombreCliente, telefonoCliente,
                    nombrePelicula1, generoPelicula1, precioPelicula1,
                    nombrePelicula2, generoPelicula2, precioPelicula2);

            mostrarResultado(unAlquiler);

        } catch (NumberFormatException error) {
            JOptionPane.showMessageDialog(unaVista,
                    "Verifique que el teléfono y los precios sean números válidos.",
                    "Dato inválido", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void mostrarResultado(alquiler unAlquiler) {
        StringBuilder texto = new StringBuilder();
        texto.append("Cliente: ").append(unAlquiler.getunCliente().getnombre()).append("\n");
        texto.append("Película 1: ").append(unAlquiler.getunPelicula1().getnombre()).append("\n");
        texto.append("Película 2: ").append(unAlquiler.getunPelicula2().getnombre());

        unaVista.getTxtResultado().setText(texto.toString());
    }
}
